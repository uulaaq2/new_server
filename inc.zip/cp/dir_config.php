<?php

// ./cp
define("ROOT_PATH", "../");