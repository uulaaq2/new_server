<?php

// require
include_once("dir_config.php");
include_once(ROOT_PATH . "inc/config.php");
include_once(ROOT_PATH . "inc/functions.php");
include_once(ROOT_PATH . "vendor/autoload.php");

// page init
page_init();

// get post data        
$username = $_POST['username'] ?? '';
$password = $_POST['password'] ?? '';
$remember_me = $_POST['remember_me'] ?? true;

// verify token    
$decoded_token = verify_token(get_cookie('token'));

// no data or token expired? bye bye
if (!$username && !$password && !$decoded_token) {
    die(send_custom("noCredentialsOrTokenProvided"));
}

// check signin type, credentials or token?
$signin_type = $username && $password ? 'credentials' : 'token';

// initiate user class
$user = new User();    

// signin with credentials
if ($signin_type === 'credentials') {
    $user->signin($username, $password, $remember_me);
} else {
    // signin with token
    $user->signin(null, null, null, $decoded_token);
}