<?php

// ./cp/user
define("ROOT_PATH", "../../");
