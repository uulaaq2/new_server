<?php

// require
include_once("dir_config.php");
include_once(ROOT_PATH . "inc/config.php");
include_once(ROOT_PATH . "inc/functions.php");
include_once(ROOT_PATH . "vendor/autoload.php");

// page init
page_init();

    // get post data  
    $account_number = $_POST["account_number"];
    $password = $_POST["password"] ?? "";

    // no data? bye bye
    if (!$password) {
        die(send_custom("noPasswordProvided"));
    }

    // initiate user class
    $user = new User();  

    // check user password
    $user->check_password($account_number, $password);

