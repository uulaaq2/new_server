<?php

// init
require_once("./inc/functions.php");
require_once("./vendor/autoload.php");  

page_init();

$date = new DateTime();                                    
] < $date->getTimestamp()) {
    return false;
}

