<?php

class DB {
    private $db;

	public function __construct() {
        $db_info = array(
            "db_host" => DB_HOST,
            "db_port" => DB_PORT,
            "db_user" => DB_USER,
            "db_pass" => DB_PASSWORD,
            "db_name" => DB_NAME,
            "db_charset" => DB_CHARSET
        );

        $this->db = new PDO("mysql:host=".$db_info['db_host'].';port='.$db_info['db_port'].';dbname='.$db_info['db_name'], $db_info['db_user'], $db_info['db_pass']);
        $this->db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_SILENT);  
        $this->db->query('SET NAMES ' . DB_CHARSET);
        $this->db->query('SET CHARACTER SET ' . DB_CHARSET);
    }

    public function select($query = "", $params = [], $fetch_type = '') {
        $stmt = $this->db->prepare($query);

        for ($i = 0; $i < count($params); $i++) {
            $stmt->bindParam($params[$i]['name'], $params[$i]['value'], $this->get_param_type($params[$i]['type']));
        }

        $stmt->execute();

        return $stmt->fetch($this->get_fetch_type($fetch_type));   
    }

    public function select_all($query = "", $params = [], $fetch_type = '') {
        $stmt = $this->db->prepare($query);

        for ($i = 0; $i < count($params); $i++) {
            $stmt->bindParam($params[$i]['name'], $params[$i]['value'], $this->get_param_type($params[$i]['type']));
        }

        $stmt->execute();

        return $stmt->fetchAll($this->get_fetch_type($fetch_type));   
    }

    public function get_param_type($type) {
        if ($type == 'STR') return PDO::PARAM_STR;       

        if ($type == 'INT') return PDO::PARAM_INT;

        return false;
    }

    public function get_fetch_type($type) {
        if (!$type) return PDO::FETCH_ASSOC;
    }   
}