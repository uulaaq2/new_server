<?php

class User Extends DB {
    function signin($username = null, $password = null, $remember_me = null, $decoded_token = null) {                
        // sign in with token
        if ($decoded_token) {
            $sql = get_sql_file("user\get_user_by_id.sql");
            $params = Array(
                Array(
                    "name" => "user_id",
                    "value" => $decoded_token->id,
                    "type" => "INT"
                )
            );
        } else {
            // signin with credentials
            $sql = get_sql_file("user\get_user_by_username.sql");
            $params = Array(
                Array(
                    "name" => "account_number",
                    "value" => $username,
                    "type" => "STR"
                ),
                Array(
                    "name" => "email_address",
                    "value" => $username,
                    "type" => "STR"
                ),
            );
        }
        
        // get user
        $user = $this->select($sql, $params);
        // no user? bye bye
        if (!$user) die(send_custom('invalidCredentials', 'Invalid credentials (1)'));

        // if signin with credentials check user password
        if (!$decoded_token) {
            if(!password_verify($password, $user["password"])) die(send_custom('invalidCredentials', 'Invalid credentials (2)'));
        }

        // user account is not valid? bye bye
        $is_user_account_valid = $this->is_user_account_valid($user);
        if ($is_user_account_valid !== "ok") {
            $message = '';
            if ($is_user_account_valid === "accountIsNotActive") $message = 'Your account is not active';
            if ($is_user_account_valid === "accountIsExpired") $message = 'Your account is expired';            
            if ($is_user_account_valid === "shouldChangePassword") $message = 'You should change your password';            
            if ($is_user_account_valid === "shouldVerifyAccount") $message = 'You should verify your password';                        

            if ($is_user_account_valid === 'shouldChangePassword' || $is_user_account_valid === 'shouldVerifyAccount') {
                die(send_custom($is_user_account_valid, $message, $this->prepare_user_payload($user)));
            } else {
                die(send_custom($is_user_account_valid, $message));
            }
        }
        
        // if signin with credentials generate token, set cookie
        if (!$decoded_token) {
            $token = generate_token($this->transform_token($user));

            // generate cookie expiry time
            $cookie_expires_in = 0;
            if ($remember_me) {
                $date = new DateTime();                                    
                $cookie_expires_in = $date->modify("+" . $user["token_expires_in"]  . "days")->getTimestamp();
            }   

            // save cookie
            save_cookie("token", $token, $cookie_expires_in);               
        }

        // return payload
        die(send_ok(null, $this->prepare_user_payload($user)));
    }
    // signin

    private function is_user_account_valid($user) {
        if($user["status"] != "Active") {        
            return "accountIsNotActive";
        }

        if ($user["account_is_expired"]) {            
            return "accountIsExpired";
        }            

        if ($user["should_change_password"]) {            
            return "shouldChangePassword";
        }      

        if ($user["should_verify_account"]) {            
            return "shouldVerifyAccount";
        }      
        
        return "ok";
    }
    // is_user_account_valid

    private function transform_user($user) {
        $exclude = [
            "account_number",
            "email_address",
            "full_name",
            "title",
            "selected_site_name"
        ];

        $reply = [];

        foreach($user as $key => $value) {
            if (in_array($key, $exclude)) {
                $reply[$key] = $value;
            }
        }
        return $reply;
    }
    // transform_user

    private function transform_token($user) {
        $date = new DateTime();                                    
        $token_expires_at = $date->modify("+" . $user["token_expires_in"]  . "days")->getTimestamp();

        $reply = [];
        $reply["id"] = $user["id"];
        $reply["expires_at"] = $token_expires_at;
        
        return $reply;
    }
    // transform_token

    private function transform_modules($modules) {
        $reply = [];

        if (count($modules) === 0) {
            return $reply;
        }

        if (count($modules) === 1) {
            $reply[] = $modules["module_name"];
        } else {
            for($i=0; $i < count($modules); $i++) {
                $reply[] = $modules[$i]["module_name"];
            }
        }
        
        return $reply;    
    }
    // transform_modules

    private function get_user_sites($user_id) {
        $sql = get_sql_file("user\get_user_sites.sql");
        $params = Array(
            Array(
                "name" => "user_id",
                "value" => $user_id,
                "type" => "INT"
            )
        );

        return $this->select_all($sql, $params);        
    }
    // get_user_sites

    private function prepare_user_payload($user) {
         // prepare user modules for payload
         $sql = get_sql_file("user/get_user_modules.sql");
         $params = Array(
             Array(
                 "name" => "user_id",
                 "value" => $user["id"],
                 "type" => "INT"
             )
         );

         $user_modules = $this->select_all($sql, $params);

         // prepare payload
         $payload = [];
         $payload["user"] = $this->transform_user($user);
         $payload["user"]["modules"] = $this->transform_modules($user_modules[0]);
         $payload["user"]["sites"] = $this->get_user_sites($user["id"]);

         return $payload;
    }
    // prepare_user_payload

    function check_password($account_number, $password) {
        $sql = get_sql_file("user\get_user_by_account_number.sql");
        $params = Array(
            Array(
                "name" => "account_number", 
                "value" => $account_number,
                "type" => "STR"
            )
        );        
        
        // get user
        $user = $this->select($sql, $params);

        // check if user returned
        if (!$user) {
            die(send_custom("invalidCredentials", "Invalid credentials (3)"));
        }
        // check user password
        if (!password_verify($user['password'])) {
            die(send_custom("invalidCredentials", "Invalid credentials (4)"));
        }

        // looks good
        die(send_ok());
    }
}