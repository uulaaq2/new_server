<?php

class User Extends DB {
    function signin($username, $password, $remember_me) {                
        // sign in with credentials
        if ($username && $password) {
            $sql_file = get_sql_file("users\get_user_by_id.sql");
            $params = Array(
                Array(
                    "name" => "account_number",
                    "value" => $username,
                    "type" => "STR"
                )
            );
            
            // get user
            $user = $this->select($sql_file, $params);
            // no user? bye bye
            if (!$user) return "no user found";
            // password is wrong? bye bye
            if(!password_verify($password, $user["password"])) return "wrong password";
            // user account is not valid? bye bye
            $is_user_account_valid = $this->is_user_account_valid($user);
            if ($is_user_account_valid !== "ok") return $is_user_account_valid;
            
            // generate token
            $token = JWT::encode(transform_token($user), JWT_SECRET_KEY, "HS256");

            // generate cookie expiry time
            $cookie_expires_in = 0;
            if ($remember_me) {
                $date = new DateTime();                                    
                $cookie_expires_in = $date->modify("+" . $user["token_expires_in"]  . "days")->getTimestamp();
            }   
            
            // save cookie
            save_cookie("token", $token, $cookie_expires_in);               

            // return payload
            return $this->prepare_user_payload($user);
        } else {
            // see if token exists?
            $token = get_cookie("token");
            // no token? bye bye
            if (!$token) return 'no token';            
            // token is not valid? bye bye
            $decoded = verify_token($token);
            if (!decoded) return 'invalid token';

            // get user
            $sql_file = "user/get_user_by_id";
            $params = Array(
                Array(
                    "name" => "user_id",
                    "value" => $decoded["id"],
                    "type" => "INT"
                )
            );
            $user = $this->select($sql_file, $params);     
            // check if user returned
            if (!$user) return "no user found";
            // check if user is actually the user?
            if ($user["id"] !== $decoded["id"]) return "invalid user";

            $is_user_account_valid = is_user_account_valid($user);
            if ($is_user_account_valid !== 'ok') return $is_user_account_valid;

            return $this->prepare_user_payload($user);
        }
    }
    // signin

    private function is_user_account_valid($user) {
        if($user["status"] != "Active") {        
            return "account is not active";
        }

        if ($user["account_is_expired"]) {            
            return "account is expired";
        }            

        if ($user["should_change_password"]) {            
            return "should change password";
        }      
        
        return "ok";
    }
    // is_user_account_valid

    private function transform_token($user) {
        $date = new DateTime();                                    
        $token_expires_at = $date->modify("+" . $user["token_expires_in"]  . "days")->getTimestamp();

        $reply = [];
        $reply["id"] = $user["id"];
        $reply["expires_at"] = $token_expires_at;
        
        return $reply;
    }
    // transform_token

    private function transform_user($user) {
        $exclude = [
            "created_at",
            "account_is_expired",
            "status",
            "password"
        ];

        $reply = [];

        foreach($user as $key => $value) {
            if (!in_array($key, $exclude)) {
                $reply[$key] = $value;
            }
        }
        return $reply;
    }
    // transform_user

    private function transform_modules($modules) {
        $reply = [];

        for($i=0; $i < count($modules); $i++) {
            $reply[] = $modules[$i]["module_name"];
        }
        
        return $reply;    
    }
    // transform_modules

    private function prepare_user_payload($user) {
         // prepare user modules for payload
         $sql_file = "user/get_user_modules.sql";
         $params = Array(
             Array(
                 "name" => "user_id",
                 "value" => $user["id"],
                 "type" => "INT"
             )
         );
         $user_modules = $this->select($sql_file, $params);

         // prepare payload
         $payload = [];
         $payload["user"] = transform_user($user);
         $payload["user"]["modules"] = $this->transform_modules($user_modules);
         $payload["user"]["sites"] = $this->get_user_sites($user["id"]);

         return $payload;
    }
}