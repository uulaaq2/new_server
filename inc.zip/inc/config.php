<?php

// dev mode
define("DEV_MODE", "DEV");

// db
define("DB_HOST", "localhost");
define("DB_PORT", 3306);
define("DB_USER", "root");
define("DB_PASSWORD", "Aa112233@@@@");
define("DB_NAME", "ibos");
define("DB_CHARSET", "UTF-8");

// paths
define("FILE_ROOT", "C:\\ibos-files\\");
define("SQL_FILE_ROOT", FILE_ROOT . "sql\\");
define("COOKIE_FILE_ROOT", FILE_ROOT);
define("ERROR_LOG_FILE", FILE_ROOT . "errors\\errors.log");

// jwt
define("JWT_SECRET_KEY", "c3MiOiJodHRwOi8vZXhhbXBsZS5");