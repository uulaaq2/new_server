<?php

use Firebase\JWT\JWT;
use Firebase\JWT\Key;

function get_app_headers() {
    header("Access-Control-Allow-Origin: http://localhost:5173");
    header("Access-Control-Allow-Credentials: true");
    header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
    header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
    header('P3P: CP="CAO PSA OUR"'); // Makes IE to support cookies
    header("Content-Type: application/json; charset=utf-8");
}
// get_app_header

function page_init() {
    ini_set('display_errors', '1');
    ini_set("error_log", ERROR_LOG_FILE);
    ini_set('display_startup_errors', '1');
    error_reporting(E_ALL);
    
    /*set_error_handler(function($errno, $errstr, $errfile, $errline){        
        $error = new stdClass();
        $error->err_no = $errno;
        $error->err_str = $errstr;
        $error->err_file = $errfile;
        $error->err_line = $errline;
        $error->err_trace = debug_print_backtrace();

        die($error);
        //throw new ErrorException($errstr, $errno, 0, $errfile, $errline);
    });*/

    get_app_headers();
}
// page_init

function send_ok($message = null, $payload = null, $response_code = 200) {        
    $reply = [];
    $reply['code'] = 'ok';
    $reply['code_src'] = 'ok';
    $reply['message'] = $message ?? '';
    if ($payload) {
        $reply['payload'] = $payload;
    }
    
    http_response_code($response_code);

    echo json_encode($reply);
}
// send_ok

function send_custom($code, $message = null, $payload = null, $response_code = 200) {
    $reply = [];
    $reply['code'] = $code;
    $reply['code_src'] = 'custom';
    $reply['message'] = $message ?? '';
    if ($payload) {
        $reply['payload'] = $payload;
    }
    
    http_response_code($response_code);
    
    echo json_encode($reply);
}
// send_custom

function send_errora($error, $response_code = 200) {
    $reply = [];
    $reply['code'] = 'error';
    $reply['message'] = $error->err_str;
    //$reply['data'] = $error;
    //$reply['trace'] = $error->err_file . "<br />" . $error->err_line;
    //$reply['trace'] = $error;

    http_response_code($response_code);

    echo json_encode($reply);
}
// send_error

function get_cookie($key) {
    if (DEV_MODE === 'production') {
        return $_COOKIE[$key] ?? false;
    } else {
        try {
            $cookie_file_name = COOKIE_FILE_ROOT . $key . ".txt";
            $cookie_file = '';

            if (!file_exists($cookie_file_name)) {
                $cookie_file = fopen($cookie_file_name, "w");
                fwrite($cookie_file, '');                    
            } else {
                $cookie_file = fopen($cookie_file_name, "r");
            }
            
            $file_size = filesize($cookie_file_name);

            if (!$file_size) {
                return '';
            } else {
                return fread($cookie_file, filesize($cookie_file_name));
            }
        } finally {
            fclose($cookie_file);
        }
    }
}
// get_cookie

function save_cookie($key, $value, $expires_in, $http_only = false) {
    $cookie_file_name = COOKIE_FILE_ROOT . $key . ".txt";
    
    if (DEV_MODE === 'production') {
        setcookie($key, $value, $expires_in, "/", "", true, $http_only);
    } else {
        try {
            $cookie_file = fopen($cookie_file_name, "w");
            fwrite($cookie_file, $value);

            return true;
        } catch(Exception $e) {
            return false;
        } finally {
            if ($cookie_file) fclose($cookie_file);                
        }
    }
}
// save cookie

function generate_token($payload) {
    return JWT::encode($payload, JWT_SECRET_KEY, "HS256");    
}
// generate_token

function verify_token($token) {
    try {     
        $decoded_token = JWT::decode($token, new Key(JWT_SECRET_KEY, 'HS256'));   

        if (!$decoded_token) {
            return false;
        }

        $date = new DateTime();                                    
        if ($decoded_token->expires_at < $date->getTimestamp()) {
            return false;
        }

        return $decoded_token;    
    } catch (\Throwable $th) {
        return false;
    }
}
// verify token

function get_sql_file($file_name) {
    try {
        $sql_file = SQL_FILE_ROOT . $file_name;
        $file = null;

        if (!file_exists($sql_file)) {
            throw new Error("Couldn't open the file, " . $sql_file . " can not be found");
        }

        $file = fopen($sql_file, "r");
        $file_size = filesize($sql_file);

        if (!$file_size) return false;

        $content = fread($file, filesize($sql_file));

        return $content;
    } finally {
        if ($file) fclose($file);
    }
}
// get_sql_file